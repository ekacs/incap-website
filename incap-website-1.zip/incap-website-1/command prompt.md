Anda adalah seorang developer web ahli yang berspesialisasi dalam static site generator, khususnya Hugo.

Tugas Anda adalah membuat tutorial lengkap untuk seorang pemula tentang cara membangun website company profile profesional menggunakan Hugo dan tema "Hugo Up Business" (https://themes.gohugo.io/themes/hugo-up-business/).

Pastikan tutorial Anda mencakup poin-poin berikut dengan penjelasan yang detail dan jelas:

1.  **Pendahuluan:** Jelaskan secara singkat mengapa Hugo adalah pilihan yang baik untuk company profile dan apa keunggulan tema "Hugo Up Business".

2.  **Langkah 1: Persiapan Lingkungan (Prasyarat):**
    * Sebutkan software apa saja yang harus diinstal (Hugo, Git).
    * Berikan perintah instalasi untuk sistem operasi umum (Windows via Scoop/Chocolatey, macOS via Homebrew, Linux via Snap/APT).
    * Jelaskan secara singkat fungsi dari masing-masing software.

3.  **Langkah 2: Inisialisasi Proyek Hugo:**
    * Tunjukkan cara membuat direktori proyek dan membuat situs Hugo baru dengan perintah `hugo new site`.
    * Jelaskan struktur folder dasar yang dihasilkan oleh Hugo.

4.  **Langkah 3: Instalasi dan Konfigurasi Tema:**
    * Berikan instruksi untuk menginstal tema "Hugo Up Business" sebagai Git Submodule. Jelaskan mengapa metode ini lebih baik daripada mengunduh manual.
    * Tunjukkan cara menyalin file konfigurasi contoh dari tema (`hugo.toml` atau `config.toml`) ke direktori utama proyek.

5.  **Langkah 4: Kustomisasi Konfigurasi Utama (`hugo.toml`):**
    * Berikan contoh file `hugo.toml` yang sudah dikustomisasi.
    * Jelaskan parameter-parameter penting seperti `baseURL`, `languageCode`, `title`, dan bagian `[params]` yang spesifik untuk tema ini (misalnya cara mengubah logo, teks footer, dan informasi kontak).
    * Jelaskan cara mengatur menu navigasi utama.

6.  **Langkah 5: Membuat Konten Halaman:**
    * Tunjukkan cara membuat halaman-halaman utama berdasarkan struktur tema, seperti:
        * Halaman Beranda (Homepage)
        * Halaman Tentang Kami (`content/about/_index.md`)
        * Halaman Layanan (`content/services/_index.md` dan `content/services/service-1.md`)
        * Halaman Kontak (`content/contact/_index.md`)
    * Sertakan contoh konten Markdown untuk setiap halaman, termasuk penggunaan *front matter* (bagian YAML/TOML di atas file).

7.  **Langkah 6: Menjalankan & Menguji Situs:**
    * Berikan perintah `hugo server` dan jelaskan outputnya.
    * Jelaskan cara mengakses situs di browser dan bagaimana fitur *live reload* bekerja.

8.  **Langkah 7: Tips Kustomisasi Tambahan:**
    * Berikan tips singkat tentang cara mengubah warna atau font dengan menambahkan file CSS kustom.

Gunakan bahasa yang mudah dipahami, sertakan blok kode untuk setiap perintah, dan berikan penjelasan "mengapa" di balik setiap langkah teknis.